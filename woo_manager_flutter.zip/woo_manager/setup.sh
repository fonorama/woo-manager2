#!/usr/bin/env bash
# اجرا در پوشه پروژه: bash setup.sh
set -e
flutter create --platforms=android --org ir.sevda --project-name woo_manager .
python3 - <<'PY'
p='android/app/src/main/AndroidManifest.xml'
s=open(p,encoding='utf-8').read()
if 'android.permission.INTERNET' not in s:
    s=s.replace('<application','<uses-permission android:name="android.permission.INTERNET"/>\n    <application',1)
if '<queries>' not in s:
    q='''<queries>
        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="sms"/></intent>
        <intent><action android:name="android.intent.action.SEND"/><data android:mimeType="text/plain"/></intent>
    </queries>
    <application'''
    s=s.replace('<application',q,1)
s=s.replace('android:label="woo_manager"','android:label="مدیریت فروشگاه"')
open(p,'w',encoding='utf-8').write(s)
PY
flutter pub get
flutter build apk --release
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
