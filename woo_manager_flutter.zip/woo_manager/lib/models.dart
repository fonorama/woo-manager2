class Site {
  final String id, name, url, key, secret;
  Site({required this.id, required this.name, required this.url, required this.key, required this.secret});

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'url': url, 'key': key, 'secret': secret};
  factory Site.fromJson(Map<String, dynamic> j) => Site(
      id: j['id'], name: j['name'], url: j['url'], key: j['key'], secret: j['secret']);

  static String normalizeUrl(String u) {
    u = u.trim();
    if (!u.startsWith('http')) u = 'https://$u';
    while (u.endsWith('/')) u = u.substring(0, u.length - 1);
    return u;
  }
}

/// تبدیل ارقام فارسی/عربی به انگلیسی و حذف جداکننده هزارگان
String toEn(String s) {
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  const ar = '٠١٢٣٤٥٦٧٨٩';
  var o = s;
  for (var i = 0; i < 10; i++) {
    o = o.replaceAll(fa[i], '$i').replaceAll(ar[i], '$i');
  }
  return o.replaceAll('٬', '').replaceAll(',', '').trim();
}

String money(dynamic v) {
  final n = double.tryParse('$v');
  if (n == null) return '—';
  return n.round().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
}

const orderStatusFa = {
  'pending': 'در انتظار پرداخت',
  'processing': 'در حال انجام',
  'on-hold': 'در انتظار بررسی',
  'completed': 'تکمیل شده',
  'cancelled': 'لغو شده',
  'refunded': 'مسترد شده',
  'failed': 'ناموفق',
};
