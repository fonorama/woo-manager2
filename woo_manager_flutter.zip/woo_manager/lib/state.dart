import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'models.dart';

final appState = AppState();

class AppState extends ChangeNotifier {
  static const _k = 'sites_v1';
  static const maxSites = 10;
  final _storage = const FlutterSecureStorage();
  List<Site> sites = [];
  String? currentId;

  Site? get current {
    for (final s in sites) {
      if (s.id == currentId) return s;
    }
    return null;
  }

  Future<void> load() async {
    final raw = await _storage.read(key: _k);
    if (raw != null) {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      sites = (j['sites'] as List).map((e) => Site.fromJson(Map<String, dynamic>.from(e))).toList();
      currentId = j['current'];
    }
    if (current == null && sites.isNotEmpty) currentId = sites.first.id;
  }

  Future<void> _save() => _storage.write(
      key: _k, value: jsonEncode({'sites': sites.map((e) => e.toJson()).toList(), 'current': currentId}));

  Future<void> add(Site s) async {
    if (sites.length >= maxSites) throw Exception('حداکثر $maxSites سایت قابل افزودن است');
    sites.add(s);
    currentId ??= s.id;
    await _save();
    notifyListeners();
  }

  Future<void> select(String id) async {
    currentId = id;
    await _save();
    notifyListeners();
  }

  Future<void> remove(String id) async {
    sites.removeWhere((e) => e.id == id);
    if (currentId == id) currentId = sites.isEmpty ? null : sites.first.id;
    await _save();
    notifyListeners();
  }
}
