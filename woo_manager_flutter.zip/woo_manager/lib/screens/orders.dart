import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../models.dart';

class OrdersScreen extends StatefulWidget {
  final Site site;
  const OrdersScreen({super.key, required this.site});
  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  late final Api api = Api(widget.site);
  final items = <J>[];
  final scroll = ScrollController();
  String status = 'any';
  int page = 1;
  bool loading = false, more = true;
  String? error;

  @override
  void initState() {
    super.initState();
    scroll.addListener(() {
      if (scroll.position.pixels > scroll.position.maxScrollExtent - 300) _load();
    });
    _load();
  }

  Future<void> _load({bool reset = false}) async {
    if (loading) return;
    if (reset) {
      items.clear();
      page = 1;
      more = true;
    }
    if (!more) return;
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final r = await api.orders(page: page, status: status);
      items.addAll(r);
      more = r.length >= 30;
      page++;
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      SizedBox(
        height: 52,
        child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
          for (final e in {'any': 'همه', ...orderStatusFa}.entries)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
              child: ChoiceChip(
                label: Text(e.value),
                selected: status == e.key,
                onSelected: (_) {
                  status = e.key;
                  _load(reset: true);
                },
              ),
            ),
        ]),
      ),
      if (error != null) Padding(padding: const EdgeInsets.all(12), child: Text(error!, style: const TextStyle(color: Colors.red))),
      Expanded(
        child: RefreshIndicator(
          onRefresh: () => _load(reset: true),
          child: ListView.builder(
            controller: scroll,
            itemCount: items.length + (loading ? 1 : 0),
            itemBuilder: (_, i) {
              if (i >= items.length) return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
              final o = items[i];
              final b = (o['billing'] ?? {}) as Map;
              return ListTile(
                title: Text('#${o['number']}  ${b['first_name'] ?? ''} ${b['last_name'] ?? ''}'),
                subtitle: Text('${orderStatusFa[o['status']] ?? o['status']}  •  ${money(o['total'])} ${o['currency_symbol'] ?? ''}\n${('${o['date_created']}').split('T').first}'),
                isThreeLine: true,
                trailing: const Icon(Icons.chevron_left),
                onTap: () async {
                  final changed = await Navigator.push<bool>(
                      context, MaterialPageRoute(builder: (_) => OrderDetailScreen(api: api, order: o)));
                  if (changed == true) _load(reset: true);
                },
              );
            },
          ),
        ),
      ),
    ]);
  }
}

class OrderDetailScreen extends StatefulWidget {
  final Api api;
  final J order;
  const OrderDetailScreen({super.key, required this.api, required this.order});
  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  late String status = widget.order['status'];
  final carrier = TextEditingController(text: 'پست');
  final code = TextEditingController();
  late final msg = TextEditingController();
  bool markComplete = true, busy = false, changed = false;

  J get o => widget.order;
  Map get b => (o['billing'] ?? {}) as Map;
  String get fullName => '${b['first_name'] ?? ''} ${b['last_name'] ?? ''}'.trim();

  @override
  void initState() {
    super.initState();
    for (final m in (o['meta_data'] as List? ?? [])) {
      if (m['key'] == '_tracking_code') code.text = '${m['value']}';
    }
    _regen();
  }

  void _regen() {
    msg.text = 'سلام ${fullName.isEmpty ? '' : '$fullName عزیز'}\n'
        'سفارش شماره ${o['number']} شما ارسال شد 📦\n'
        'روش ارسال: ${carrier.text.trim()}\n'
        'کد رهگیری: ${toEn(code.text)}\n'
        'مبلغ سفارش: ${money(o['total'])} ${o['currency_symbol'] ?? ''}\n'
        'از خرید شما سپاسگزاریم.';
  }

  /// شماره موبایل ایران → فرمت بین‌المللی بدون +
  String get phone {
    var p = toEn('${b['phone'] ?? ''}').replaceAll(RegExp(r'[^0-9]'), '');
    if (p.startsWith('00')) p = p.substring(2);
    if (p.startsWith('0')) p = '98${p.substring(1)}';
    if (p.length == 10 && p.startsWith('9')) p = '98$p';
    return p;
  }

  void toast(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  Future<void> _open(String url) async {
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok) toast('برنامه مورد نظر پیدا نشد');
  }

  Future<void> _saveToSite() async {
    setState(() => busy = true);
    try {
      final c = toEn(code.text);
      final data = <String, dynamic>{
        'meta_data': [
          {'key': '_tracking_code', 'value': c},
          {'key': '_tracking_carrier', 'value': carrier.text.trim()},
        ],
        if (markComplete) 'status': 'completed',
      };
      final r = await widget.api.updateOrder(o['id'] as int, data);
      await widget.api.addNote(o['id'] as int, 'کد رهگیری (${carrier.text.trim()}): $c');
      status = r['status'];
      changed = true;
      toast('در سایت ثبت شد ✅');
    } catch (e) {
      toast(e.toString().replaceFirst('Exception: ', ''));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final items = (o['line_items'] as List? ?? []).cast<Map>();
    final ship = (o['shipping'] ?? {}) as Map;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) Navigator.pop(context, changed);
      },
      child: Scaffold(
        appBar: AppBar(title: Text('سفارش #${o['number']}')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(fullName, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                SelectableText('${b['phone'] ?? ''}'),
                Text('وضعیت: ${orderStatusFa[status] ?? status}'),
                const SizedBox(height: 8),
                Text('آدرس: ${ship['state'] ?? ''} ${ship['city'] ?? ''} ${ship['address_1'] ?? ''} ${ship['address_2'] ?? ''}  کدپستی: ${ship['postcode'] ?? ''}'),
                const Divider(),
                for (final it in items) Text('• ${it['name']}  ×${it['quantity']}'),
                const Divider(),
                Text('جمع کل: ${money(o['total'])} ${o['currency_symbol'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.bold)),
                if ('${o['customer_note'] ?? ''}'.isNotEmpty) Text('توضیح مشتری: ${o['customer_note']}'),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Text('ارسال کد رهگیری به مشتری', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          TextField(controller: carrier, onChanged: (_) => setState(_regen), decoration: const InputDecoration(labelText: 'روش ارسال (پست / تیپاکس / ...)', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: code, onChanged: (_) => setState(_regen), keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'کد رهگیری', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: msg, maxLines: 6, decoration: const InputDecoration(labelText: 'متن پیام (قابل ویرایش)', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            FilledButton.icon(
              onPressed: () => _open('sms:${b['phone'] ?? ''}?body=${Uri.encodeComponent(msg.text)}'),
              icon: const Icon(Icons.sms),
              label: const Text('پیامک'),
            ),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFF25D366)),
              onPressed: () => _open('https://wa.me/$phone?text=${Uri.encodeComponent(msg.text)}'),
              icon: const Icon(Icons.chat),
              label: const Text('واتس‌اپ'),
            ),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: Colors.orange),
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: msg.text));
                Share.share(msg.text); // در لیست، «ایتا» را انتخاب کنید
              },
              icon: const Icon(Icons.send),
              label: const Text('ایتا'),
            ),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: Colors.green.shade800),
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: msg.text));
                Share.share(msg.text); // در لیست، «بله» را انتخاب کنید
              },
              icon: const Icon(Icons.send),
              label: const Text('بله'),
            ),
          ]),
          const SizedBox(height: 4),
          const Text('برای ایتا و بله، پیام کپی می‌شود و لیست اشتراک‌گذاری باز می‌شود؛ برنامه و مخاطب را انتخاب کنید.',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
          const Divider(height: 32),
          SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('وضعیت سفارش «تکمیل شده» شود'), value: markComplete, onChanged: (v) => setState(() => markComplete = v)),
          OutlinedButton.icon(
            onPressed: busy ? null : _saveToSite,
            icon: busy ? const SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.cloud_upload),
            label: const Text('ثبت کد رهگیری در سایت'),
          ),
        ]),
      ),
    );
  }
}
