import 'package:flutter/material.dart';
import '../api.dart';
import '../models.dart';
import '../state.dart';

class SitesScreen extends StatelessWidget {
  const SitesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appState,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: Text('سایت‌های من (${appState.sites.length}/${AppState.maxSites})')),
        body: appState.sites.isEmpty
            ? const Center(
                child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('هنوز سایتی اضافه نکرده‌اید.\nروی دکمه «افزودن سایت» بزنید.', textAlign: TextAlign.center),
              ))
            : ListView(
                children: [
                  for (final s in appState.sites)
                    ListTile(
                      leading: Icon(s.id == appState.currentId ? Icons.check_circle : Icons.circle_outlined,
                          color: s.id == appState.currentId ? Colors.teal : null),
                      title: Text(s.name),
                      subtitle: Text(s.url, textDirection: TextDirection.ltr, textAlign: TextAlign.right),
                      onTap: () async {
                        await appState.select(s.id);
                        if (context.mounted && Navigator.canPop(context)) Navigator.pop(context);
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (c) => AlertDialog(
                              title: Text('حذف «${s.name}»؟'),
                              content: const Text('فقط از برنامه حذف می‌شود، نه از سایت.'),
                              actions: [
                                TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('انصراف')),
                                FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف')),
                              ],
                            ),
                          );
                          if (ok == true) appState.remove(s.id);
                        },
                      ),
                    ),
                ],
              ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: appState.sites.length >= AppState.maxSites
              ? null
              : () => showModalBottomSheet(
                  context: context, isScrollControlled: true, builder: (_) => const _AddSiteSheet()),
          icon: const Icon(Icons.add),
          label: const Text('افزودن سایت'),
        ),
      ),
    );
  }
}

class _AddSiteSheet extends StatefulWidget {
  const _AddSiteSheet();
  @override
  State<_AddSiteSheet> createState() => _AddSiteSheetState();
}

class _AddSiteSheetState extends State<_AddSiteSheet> {
  final name = TextEditingController(), url = TextEditingController();
  final key = TextEditingController(), secret = TextEditingController();
  bool busy = false;
  String? err;

  Future<void> save() async {
    if ([name, url, key, secret].any((c) => c.text.trim().isEmpty)) {
      setState(() => err = 'همه فیلدها را پر کنید');
      return;
    }
    setState(() {
      busy = true;
      err = null;
    });
    final site = Site(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name.text.trim(),
      url: Site.normalizeUrl(url.text),
      key: key.text.trim(),
      secret: secret.text.trim(),
    );
    try {
      await Api(site).ping(); // تست اتصال
      await appState.add(site);
      await appState.select(site.id);
      if (mounted) {
        Navigator.pop(context);
        if (Navigator.canPop(context)) Navigator.pop(context);
      }
    } catch (e) {
      setState(() {
        busy = false;
        err = 'اتصال برقرار نشد: ${e.toString().replaceFirst('Exception: ', '')}';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    const ltr = TextDirection.ltr;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('افزودن سایت', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'نام دلخواه (مثلاً فروشگاه اصلی)', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: url, textDirection: ltr, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'آدرس سایت (example.com)', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: key, textDirection: ltr, decoration: const InputDecoration(labelText: 'Consumer Key (ck_...)', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: secret, textDirection: ltr, decoration: const InputDecoration(labelText: 'Consumer Secret (cs_...)', border: OutlineInputBorder())),
          const SizedBox(height: 6),
          const Text('ووکامرس ← تنظیمات ← پیشرفته ← REST API ← افزودن کلید (دسترسی: خواندن/نوشتن)',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
          if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 12),
          FilledButton(onPressed: busy ? null : save, child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('تست اتصال و ذخیره')),
        ]),
      ),
    );
  }
}
