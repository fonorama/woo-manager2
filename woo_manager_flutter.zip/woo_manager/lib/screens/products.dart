import 'package:flutter/material.dart';
import '../api.dart';
import '../models.dart';

class ProductsScreen extends StatefulWidget {
  final Site site;
  const ProductsScreen({super.key, required this.site});
  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  late final Api api = Api(widget.site);
  final items = <J>[];
  final sel = <int>{};
  final q = TextEditingController();
  final scroll = ScrollController();
  int page = 1;
  bool loading = false, more = true;
  String? error;

  @override
  void initState() {
    super.initState();
    scroll.addListener(() {
      if (scroll.position.pixels > scroll.position.maxScrollExtent - 300) _load();
    });
    _load();
  }

  Future<void> _load({bool reset = false}) async {
    if (loading) return;
    if (reset) {
      items.clear();
      sel.clear();
      page = 1;
      more = true;
    }
    if (!more) return;
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final r = await api.products(page: page, q: toEn(q.text));
      items.addAll(r);
      more = r.length >= 30;
      page++;
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
    }
    if (mounted) setState(() => loading = false);
  }

  String stockText(J p) {
    if (p['manage_stock'] == true) return '${p['stock_quantity'] ?? 0}';
    return p['stock_status'] == 'instock' ? 'موجود' : 'ناموجود';
  }

  void _toggle(int id) => setState(() => sel.contains(id) ? sel.remove(id) : sel.add(id));

  Future<void> _edit(List<J> list) async {
    final ok = await showModalBottomSheet<bool>(
        context: context, isScrollControlled: true, builder: (_) => BulkEditSheet(items: list, api: api));
    if (ok == true) _load(reset: true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: TextField(
            controller: q,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _load(reset: true),
            decoration: InputDecoration(
              hintText: 'جستجوی محصول...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(icon: const Icon(Icons.refresh), onPressed: () => _load(reset: true)),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
              isDense: true,
            ),
          ),
        ),
        if (sel.isNotEmpty)
          Container(
            color: Theme.of(context).colorScheme.secondaryContainer,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(children: [
              Text('${sel.length} انتخاب شده'),
              const Spacer(),
              TextButton(onPressed: () => setState(() => sel.addAll(items.map((e) => e['id'] as int))), child: const Text('همه')),
              TextButton(onPressed: () => setState(sel.clear), child: const Text('لغو')),
              FilledButton.icon(
                onPressed: () => _edit(items.where((e) => sel.contains(e['id'])).toList()),
                icon: const Icon(Icons.edit),
                label: const Text('ویرایش گروهی'),
              ),
            ]),
          ),
        if (error != null) Padding(padding: const EdgeInsets.all(12), child: Text(error!, style: const TextStyle(color: Colors.red))),
        Expanded(
          child: RefreshIndicator(
            onRefresh: () => _load(reset: true),
            child: ListView.builder(
              controller: scroll,
              itemCount: items.length + (loading ? 1 : 0),
              itemBuilder: (_, i) {
                if (i >= items.length) return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
                final p = items[i];
                final id = p['id'] as int;
                final img = (p['images'] as List).isNotEmpty ? p['images'][0]['src'] as String : null;
                return ListTile(
                  selected: sel.contains(id),
                  leading: SizedBox(
                    width: 48,
                    height: 48,
                    child: img == null
                        ? const Icon(Icons.image_not_supported_outlined)
                        : ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: Image.network(img, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined))),
                  ),
                  title: Text('${p['name']}', maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text(p['type'] == 'variable'
                      ? 'محصول متغیر'
                      : 'قیمت: ${money(p['regular_price'])}${(p['sale_price'] ?? '') != '' ? ' (حراج ${money(p['sale_price'])})' : ''}  •  موجودی: ${stockText(p)}'),
                  trailing: sel.isNotEmpty ? Checkbox(value: sel.contains(id), onChanged: (_) => _toggle(id)) : null,
                  onTap: () => sel.isNotEmpty ? _toggle(id) : _edit([p]),
                  onLongPress: () => _toggle(id),
                );
              },
            ),
          ),
        ),
      ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final ok = await showModalBottomSheet<bool>(
              context: context, isScrollControlled: true, builder: (_) => _AddProductSheet(api: api));
          if (ok == true) _load(reset: true);
        },
        icon: const Icon(Icons.add),
        label: const Text('محصول جدید'),
      ),
    );
  }
}

/// ویرایش گروهی (یا تکی) قیمت و موجودی
class BulkEditSheet extends StatefulWidget {
  final List<J> items;
  final Api api;
  const BulkEditSheet({super.key, required this.items, required this.api});
  @override
  State<BulkEditSheet> createState() => _BulkEditSheetState();
}

class _BulkEditSheetState extends State<BulkEditSheet> {
  static const modes = {
    'none': 'بدون تغییر قیمت',
    'up': 'افزایش درصدی',
    'down': 'کاهش درصدی',
    'add': 'افزودن مبلغ ثابت',
    'sub': 'کم کردن مبلغ ثابت',
    'set': 'قیمت جدید (برای همه)',
  };
  String mode = 'none';
  bool stockOn = false, busy = false;
  final val = TextEditingController(), step = TextEditingController(), stock = TextEditingController();
  String? err;

  String? newPrice(J p) {
    if (mode == 'none' || p['type'] == 'variable') return null;
    final v = double.tryParse(toEn(val.text));
    if (v == null) return null;
    final cur = double.tryParse('${p['regular_price']}') ?? 0;
    double n;
    switch (mode) {
      case 'up':
        n = cur * (1 + v / 100);
      case 'down':
        n = cur * (1 - v / 100);
      case 'add':
        n = cur + v;
      case 'sub':
        n = cur - v;
      default:
        n = v;
    }
    final st = double.tryParse(toEn(step.text)) ?? 0;
    if (st > 0) n = (n / st).round() * st;
    if (n < 0) n = 0;
    return n.round().toString();
  }

  Future<void> apply() async {
    final q = int.tryParse(toEn(stock.text));
    if (stockOn && q == null) {
      setState(() => err = 'عدد موجودی را وارد کنید');
      return;
    }
    if (mode != 'none' && double.tryParse(toEn(val.text)) == null) {
      setState(() => err = 'مقدار قیمت را وارد کنید');
      return;
    }
    final updates = <J>[];
    for (final p in widget.items) {
      final m = <String, dynamic>{'id': p['id']};
      final np = newPrice(p);
      if (np != null) m['regular_price'] = np;
      if (stockOn && q != null && p['type'] != 'variable') {
        m['manage_stock'] = true;
        m['stock_quantity'] = q;
        m['stock_status'] = q > 0 ? 'instock' : 'outofstock';
      }
      if (m.length > 1) updates.add(m);
    }
    if (updates.isEmpty) {
      setState(() => err = 'تغییری برای اعمال وجود ندارد');
      return;
    }
    setState(() {
      busy = true;
      err = null;
    });
    try {
      final errors = await widget.api.batchUpdate(updates);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(errors == 0 ? '${updates.length} محصول به‌روز شد ✅' : '${updates.length - errors} موفق، $errors خطا')));
      Navigator.pop(context, true);
    } catch (e) {
      setState(() {
        busy = false;
        err = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final sample = widget.items.first;
    final np = newPrice(sample);
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(widget.items.length == 1 ? 'ویرایش: ${sample['name']}' : 'ویرایش گروهی ${widget.items.length} محصول',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: mode,
            decoration: const InputDecoration(labelText: 'تغییر قیمت', border: OutlineInputBorder()),
            items: [for (final e in modes.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
            onChanged: (v) => setState(() => mode = v!),
          ),
          if (mode != 'none') ...[
            const SizedBox(height: 10),
            TextField(
              controller: val,
              keyboardType: TextInputType.number,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(labelText: mode == 'up' || mode == 'down' ? 'درصد' : 'مبلغ', border: const OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: step,
              keyboardType: TextInputType.number,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(labelText: 'رُند کردن به نزدیک‌ترین (اختیاری، مثلاً 1000)', border: OutlineInputBorder()),
            ),
            if (np != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text('نمونه: ${money(sample['regular_price'])}  ←  ${money(np)}', style: const TextStyle(color: Colors.teal)),
              ),
          ],
          SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('تغییر موجودی'), value: stockOn, onChanged: (v) => setState(() => stockOn = v)),
          if (stockOn)
            TextField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'موجودی جدید (برای همه)', border: OutlineInputBorder())),
          if (widget.items.any((e) => e['type'] == 'variable'))
            const Padding(padding: EdgeInsets.only(top: 8), child: Text('محصولات متغیر در این نسخه تغییر نمی‌کنند.', style: TextStyle(fontSize: 12, color: Colors.black54))),
          if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 12),
          FilledButton(onPressed: busy ? null : apply, child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('اعمال تغییرات')),
        ]),
      ),
    );
  }
}

class _AddProductSheet extends StatefulWidget {
  final Api api;
  const _AddProductSheet({required this.api});
  @override
  State<_AddProductSheet> createState() => _AddProductSheetState();
}

class _AddProductSheetState extends State<_AddProductSheet> {
  final name = TextEditingController(), price = TextEditingController(), stock = TextEditingController();
  final sku = TextEditingController(), desc = TextEditingController();
  bool busy = false;
  String? err;

  Future<void> save() async {
    if (name.text.trim().isEmpty || double.tryParse(toEn(price.text)) == null) {
      setState(() => err = 'نام و قیمت الزامی است');
      return;
    }
    setState(() {
      busy = true;
      err = null;
    });
    final q = int.tryParse(toEn(stock.text));
    try {
      await widget.api.createProduct({
        'name': name.text.trim(),
        'type': 'simple',
        'status': 'publish',
        'regular_price': toEn(price.text),
        if (sku.text.trim().isNotEmpty) 'sku': sku.text.trim(),
        if (desc.text.trim().isNotEmpty) 'short_description': desc.text.trim(),
        if (q != null) ...{'manage_stock': true, 'stock_quantity': q, 'stock_status': q > 0 ? 'instock' : 'outofstock'},
      });
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() {
        busy = false;
        err = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('محصول جدید', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'نام محصول', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قیمت', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'موجودی (اختیاری)', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: sku, decoration: const InputDecoration(labelText: 'کد محصول / SKU (اختیاری)', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: desc, maxLines: 3, decoration: const InputDecoration(labelText: 'توضیح کوتاه (اختیاری)', border: OutlineInputBorder())),
          if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 12),
          FilledButton(onPressed: busy ? null : save, child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('ثبت محصول')),
        ]),
      ),
    );
  }
}
