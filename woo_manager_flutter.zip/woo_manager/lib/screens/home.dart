import 'package:flutter/material.dart';
import '../state.dart';
import 'products.dart';
import 'orders.dart';
import 'sites.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final site = appState.current!;
    return Scaffold(
      appBar: AppBar(
        title: Text(site.name),
        actions: [
          TextButton.icon(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SitesScreen())),
            icon: const Icon(Icons.swap_horiz),
            label: const Text('سایت‌ها'),
          ),
        ],
      ),
      body: IndexedStack(index: tab, children: [
        ProductsScreen(key: ValueKey('p${site.id}'), site: site),
        OrdersScreen(key: ValueKey('o${site.id}'), site: site),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'محصولات'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'سفارش‌ها'),
        ],
      ),
    );
  }
}
