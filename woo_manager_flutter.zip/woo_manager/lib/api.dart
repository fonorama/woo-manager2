import 'dart:convert';
import 'package:http/http.dart' as http;
import 'models.dart';

typedef J = Map<String, dynamic>;

class Api {
  final Site site;
  Api(this.site);

  Map<String, String> get _h => {
        'Authorization': 'Basic ${base64Encode(utf8.encode('${site.key}:${site.secret}'))}',
        'Content-Type': 'application/json; charset=utf-8',
      };

  Uri _u(String p, [Map<String, dynamic>? q]) {
    final params = <String, String>{
      'consumer_key': site.key, // برای هاست‌هایی که هدر Authorization را حذف می‌کنند
      'consumer_secret': site.secret,
      ...?q?.map((k, v) => MapEntry(k, '$v')),
    };
    return Uri.parse('${site.url}/wp-json/wc/v3/$p').replace(queryParameters: params);
  }

  dynamic _dec(http.Response r) {
    final body = utf8.decode(r.bodyBytes);
    if (r.statusCode >= 200 && r.statusCode < 300) return jsonDecode(body);
    var m = 'خطا ${r.statusCode}';
    try {
      m = jsonDecode(body)['message'] ?? m;
    } catch (_) {}
    throw Exception(m);
  }

  Future<dynamic> _get(String p, [Map<String, dynamic>? q]) async =>
      _dec(await http.get(_u(p, q), headers: _h).timeout(const Duration(seconds: 30)));
  Future<dynamic> _post(String p, Object body) async =>
      _dec(await http.post(_u(p), headers: _h, body: jsonEncode(body)).timeout(const Duration(seconds: 60)));
  Future<dynamic> _put(String p, Object body) async =>
      _dec(await http.put(_u(p), headers: _h, body: jsonEncode(body)).timeout(const Duration(seconds: 30)));

  Future<void> ping() => _get('products', {'per_page': 1});

  Future<List<J>> products({int page = 1, String q = ''}) async {
    final r = await _get('products', {'page': page, 'per_page': 30, if (q.isNotEmpty) 'search': q});
    return (r as List).cast<J>();
  }

  /// به‌روزرسانی گروهی؛ برمی‌گرداند تعداد خطاها
  Future<int> batchUpdate(List<J> updates) async {
    var errors = 0;
    for (var i = 0; i < updates.length; i += 100) {
      final chunk = updates.sublist(i, i + 100 > updates.length ? updates.length : i + 100);
      final r = await _post('products/batch', {'update': chunk}) as J;
      for (final u in (r['update'] as List? ?? [])) {
        if (u is Map && u['error'] != null) errors++;
      }
    }
    return errors;
  }

  Future<J> createProduct(J data) async => (await _post('products', data) as J);

  Future<List<J>> orders({int page = 1, String status = 'any'}) async {
    final r = await _get('orders', {'page': page, 'per_page': 30, 'status': status});
    return (r as List).cast<J>();
  }

  Future<J> updateOrder(int id, J data) async => (await _put('orders/$id', data) as J);
  Future<void> addNote(int id, String note, {bool toCustomer = false}) =>
      _post('orders/$id/notes', {'note': note, 'customer_note': toCustomer});
}
