# مدیریت فروشگاه ووکامرس (Flutter)

## ساخت APK
1. Flutter SDK را نصب کنید (flutter.dev) و `flutter doctor` را بزنید.
2. در پوشه پروژه: `bash setup.sh`
3. فایل خروجی: `build/app/outputs/flutter-apk/app-release.apk`

## اتصال سایت
ووکامرس ← تنظیمات ← پیشرفته ← REST API ← افزودن کلید (دسترسی «خواندن/نوشتن») ← Consumer Key و Secret را در برنامه وارد کنید. سایت باید HTTPS باشد.
